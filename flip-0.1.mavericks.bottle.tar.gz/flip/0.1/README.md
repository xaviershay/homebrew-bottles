# Flip lets you angrily flip things

    $ flip the internet
    (╯°□°）╯︵  ʇǝuɹǝʇuı ǝɥʇ

# Install

    go get github.com/anthonybishopric/flip
